<?php
	require 'user.php';
	login($_GET['email'],$_GET['password']);
?>