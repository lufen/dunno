<?php
	require_once 'user.php';
	registerUser($_GET['email'],$_GET['password']);
?>
